#ifndef MBFL_NLS_RU_H
#define MBFL_NLS_RU_H

#include "mbfilter.h"
#include "nls_ru.h"

extern const mbfl_language mbfl_language_russian;

#endif /* MBFL_NLS_RU_H */
